# Aura Agent — Vercel-ready Demo

В этом ZIP-пакете — минимальный Vite + React проект с 3D-сценой (three + @react-three/fiber/@react-three/drei)
и простым чат-интерфейсом. Подходит для размещения на Vercel.

## Быстрый старт локально

1. Распакуй ZIP.
2. Открой папку в терминале.
3. Установи зависимости:
   ```bash
   npm install
   ```
4. Запусти локально:
   ```bash
   npm run dev
   ```
   Открой `http://localhost:5173` (порт может отличаться).

## Развёртывание на Vercel

Есть два простых пути:

### Через GitHub (рекомендуется)
1. Инициализируй git и залей репозиторий на GitHub.
   ```bash
   git init
   git add .
   git commit -m "initial"
   git branch -M main
   git remote add origin <your-github-url>
   git push -u origin main
   ```
2. Зайди на https://vercel.com, создай проект → Import from GitHub → выбери репозиторий → Deploy.
3. Через пару минут сайт будет доступен по `your-project.vercel.app`. Можно подключить свой домен в настройках проекта.

### Загрузка ZIP прямо в Vercel (если не хотите Git)
1. На Vercel: New Project → Import → Upload ZIP → выбери этот архив → Deploy.

## Как изменить дизайн позже

- Файлы находятся в `src/components/AuraAgentSite.jsx` и `src/App.jsx`.
- Меняй разметку/классы — сайт обновится после перезаливки или при локальной отладке.
- Для сложной стилизации лучше подключить Tailwind локально (в проекте сейчас используется Tailwind через CDN для быстрой сборки).
- Чтобы загрузить свои 3D-ассеты, импортируй GLTF/GLB и замени `FloatingOrb` на модель.

## Интеграция с твоим AI-агентом

В `src/components/AuraAgentSite.jsx` функция `ensureSend` отправляет сообщения — замени на вызов API твоего агента.
Лучше использовать серверный эндпоинт (для безопасности API-ключа) или WebSocket для стриминга.

Если хочешь, могу:
- добавить пример вызова fetch к твоему endpoint (покажи формат),
- или настроить WebSocket-стриминг в карточке чата.

--- 
Удачного развёртывания!
