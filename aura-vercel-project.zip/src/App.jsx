import React from 'react'
import AuraAgentSite from './components/AuraAgentSite'

export default function App(){
  return <AuraAgentSite />
}
