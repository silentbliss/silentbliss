# Aura Agent — Vercel-ready Demo

В этом ZIP-пакете — минимальный Vite + React проект с 3D-сценой (three + @react-three/fiber/@react-three/drei)
и простым чат-интерфейсом. Подходит для размещения на Vercel.

## Быстрый старт локально

1. Распакуй ZIP.
2. Открой папку в терминале.
3. Установи зависимости:
   npm install
4. Запусти локально:
   npm run dev

## Развёртывание на Vercel

### Через GitHub (рекомендуется)
1. Инициализируй git и залей репозиторий на GitHub.
2. На Vercel: Import from GitHub → выбери репозиторий → Deploy.

### ZIP (быстро)
1. На Vercel: New Project → Import → Upload ZIP → выбери этот архив → Deploy.

