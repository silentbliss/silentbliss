import React, { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Float, Stars, Html } from '@react-three/drei';

function FloatingOrb({ speed = 1.2 }) {
  const ref = useRef();
  useFrame((state) => {
    const t = state.clock.getElapsedTime() * speed;
    ref.current.rotation.x = t * 0.15;
    ref.current.rotation.y = t * 0.25;
    ref.current.position.y = Math.sin(t * 0.6) * 0.4 + 0.4;
  });

  return (
    <Float floatIntensity={1} rotationIntensity={0.6}>
      <mesh ref={ref} scale={[1.6,1.6,1.6]}>
        <icosahedronGeometry args={[1, 6]} />
        <meshStandardMaterial metalness={0.6} roughness={0.15} envMapIntensity={0.8} />
      </mesh>
    </Float>
  );
}

function Backdrop(){
  return (
    <>
      <Stars radius={50} depth={20} count={1000} factor={4} saturation={0} fade />
      <ambientLight intensity={0.9} />
      <directionalLight position={[5,5,5]} intensity={0.7} />
    </>
  );
}

function ChatCard({ onSend }) {
  const [value, setValue] = useState('');
  const [messages, setMessages] = useState([
    { from: 'agent', text: 'Привет. Я готов помочь — спроси что угодно.' },
  ]);

  async function send() {
    if (!value.trim()) return;
    const userMsg = { from: 'you', text: value };
    setMessages((m) => [...m, userMsg]);
    setValue('');
    try {
      const reply = await onSend ? await onSend(userMsg.text) : await defaultSend(userMsg.text);
      setMessages((m) => [...m, { from: 'agent', text: reply || '...' }]);
    } catch (e) {
      setMessages((m) => [...m, { from: 'agent', text: 'Ошибка: не удалось связаться с агентом.' }]);
    }
  }

  async function defaultSend(msg){
    await new Promise((r)=>setTimeout(r,600));
    return `Демо-ответ: "${msg}"`;
  }

  return (
    <div className="w-full max-w-md bg-white/6 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-xl text-white">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-400 via-pink-500 to-indigo-400 flex items-center justify-center text-black font-bold">AI</div>
        <div>
          <div className="text-sm font-semibold">Aura Agent</div>
          <div className="text-xs opacity-70">Онлайн — отвечает мгновенно</div>
        </div>
      </div>

      <div className="h-64 overflow-auto mb-3 px-2 py-1 space-y-2">
        {messages.map((m,i)=>(
          <div key={i} className={`text-sm p-2 rounded-lg max-w-[85%] ${m.from==='you' ? 'ml-auto bg-white/10 text-right' : 'bg-white/4'}`}>
            {m.text}
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e)=>setValue(e.target.value)}
          onKeyDown={(e)=>e.key === 'Enter' && send()}
          className="flex-1 bg-transparent border border-white/6 rounded-xl px-3 py-2 text-white text-sm outline-none"
          placeholder="Напиши сообщение агенту..."
        />
        <button onClick={send} className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 font-semibold text-black">Отправить</button>
      </div>
    </div>
  );
}

export default function AuraAgentSite({ sendToAgent }){
  const ensureSend = async (msg) => {
    if (sendToAgent) return await sendToAgent(msg);
    await new Promise((r)=>setTimeout(r,500));
    return `Я получил: "${msg}" — настройте интеграцию для реальных ответов.`;
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center">
      <div className="container mx-auto px-6 py-12 grid grid-cols-12 gap-8">
        <div className="col-span-7 relative rounded-3xl overflow-hidden shadow-2xl" style={{height: '700px'}}>
          <div className="absolute inset-0 z-10 flex items-start justify-between p-6">
            <div>
              <h1 className="text-4xl font-bold leading-tight">Aura — персональный AI агент</h1>
              <p className="mt-2 text-lg opacity-80 max-w-xl">Визуальная оболочка и чат с 3D-дизайном. Интегрируй своего агента и получи уникальный интерфейс.</p>
            </div>
            <div className="space-x-3">
              <button className="px-4 py-2 rounded-lg border border-white/10 text-sm">Документация</button>
              <button className="px-4 py-2 rounded-lg bg-white/6 text-sm">Профиль</button>
            </div>
          </div>

          <div className="h-full">
            <Canvas camera={{ position: [0,0,6], fov: 45 }}>
              <Backdrop />
              <OrbitControls enablePan={false} enableZoom={false} enableRotate={false} />
              <FloatingOrb />
              <Html center position={[1.4,0.6,0]} style={{ pointerEvents: 'none' }}>
                <div className="px-4 py-2 rounded-xl bg-white/8 backdrop-blur-md border border-white/8 text-black text-sm font-medium">Активность ядра: <span className="font-bold">stable</span></div>
              </Html>
            </Canvas>
          </div>

          <div className="absolute bottom-6 left-6 z-20">
            <div className="rounded-xl p-3 bg-gradient-to-r from-white/6 to-white/4 border border-white/6 backdrop-blur">
              <div className="text-xs opacity-80">Производительность</div>
              <div className="text-sm font-semibold">GPU · 60 FPS · Low latency</div>
            </div>
          </div>
        </div>

        <div className="col-span-5 flex flex-col justify-center items-end">
          <ChatCard onSend={ensureSend} />

          <div className="mt-6 text-right opacity-80 text-sm max-w-sm">
            <div>Как подключить вашего агента:</div>
            <ol className="list-decimal list-inside mt-2">
              <li>Добавьте endpoint вашего агента в параметр <code>sendToAgent</code>.</li>
              <li>Настройте авторизацию (API key / JWT) на сервере.</li>
              <li>При желании используйте websocket для потоковых ответов.</li>
            </ol>
          </div>
        </div>
      </div>

      <div className="fixed bottom-5 left-1/2 -translate-x-1/2 text-xs opacity-60">© Aura-style · 3D demo · customize freely</div>
    </div>
  );
}
